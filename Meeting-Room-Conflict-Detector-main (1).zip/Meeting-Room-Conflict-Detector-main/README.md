# Meeting Room Conflict Detector

A full-stack scheduling application that checks a list of proposed meetings, flags overlapping bookings, and suggests the next available free slot. Built as a practical implementation of the classic **Merge Intervals** algorithm from Data Structures and Algorithms.

---

## Table of Contents

- [Overview](#overview)
- [Tech Stack](#tech-stack)
- [Project Structure](#project-structure)
- [How It Works](#how-it-works)
- [Algorithm Explained](#algorithm-explained)
- [Getting Started](#getting-started)
- [API Reference](#api-reference)
- [Screenshots](#screenshots)
- [Real-World Relevance](#real-world-relevance)
- [Future Improvements](#future-improvements)

---

## Overview

In any organization with shared meeting rooms, scheduling conflicts are inevitable. When multiple teams try to book the same room for overlapping time slots, it creates confusion and wasted productivity.

This project automates that process. It accepts a batch of proposed meetings, detects double-bookings using interval merging, and computes the gaps between occupied blocks to suggest available slots for rescheduling. This is the same logic that powers features like "Find a time" in Google Calendar and Microsoft Outlook.

---

## Tech Stack

| Layer | Technology | Purpose |
| ------- | ----------- | --------- |
| Frontend | React (Vite) | Dynamic UI for meeting input and result display |
| Backend | Node.js, Express | REST API that runs the scheduling algorithm |
| Core Logic | JavaScript | Merge Intervals algorithm using native array methods |

No external date/time libraries were used. Time comparisons are done using a simple minutes-from-midnight integer conversion, keeping the codebase minimal and focused on the algorithm.

---

## Project Structure

```
meeting-room-conflict-detector/
├── backend/
│   ├── index.js          # Express server with single POST endpoint
│   ├── scheduler.js      # Core algorithm: merge intervals + gap finding
│   ├── package.json
│   └── node_modules/
├── frontend/
│   ├── src/
│   │   ├── App.jsx       # Main React component
│   │   └── index.css     # Minimal styling
│   ├── package.json
│   └── node_modules/
├── .gitignore
└── README.md
```

---

## How It Works

1. The user opens the React frontend and enters meeting details (title, start time, end time) one by one.
2. Once all meetings are added, they click **Check Conflicts**.
3. The frontend sends a `POST` request to the backend with the list of meetings.
4. The backend:
   - Converts time strings to integers (minutes from midnight).
   - Sorts meetings by start time.
   - Runs a single-pass merge to detect overlapping intervals.
   - Scans gaps between merged blocks to find available slots.
5. The result (conflicts + free slots) is returned as JSON and displayed in the UI.

---

## Algorithm Explained

The core of this project is the **Merge Intervals** algorithm. Here is how it works step by step:

### Step 1: Normalize

Convert time strings to integers for easy comparison.

```
"09:30" → 9 × 60 + 30 = 570
"14:00" → 14 × 60 + 0 = 840
```

### Step 2: Sort

Sort all meetings by start time. This ensures overlaps can only occur between adjacent elements, enabling a linear scan.

### Step 3: Merge and Detect

Iterate through sorted meetings. If the current meeting's end time exceeds the next meeting's start time, they overlap. Merge them into one block and flag the conflict.

```
Meeting A: [570, 630]  (09:30 - 10:30)
Meeting B: [600, 660]  (10:00 - 11:00)
→ Overlap detected. Merged block: [570, 660]
```

### Step 4: Find Gaps

After merging, scan the spaces between blocks within working hours (09:00 - 17:00). Any gap that fits the requested meeting duration is returned as a suggestion.

### Complexity

| Metric | Value |
|--------|-------|
| Time | O(N log N) — dominated by the sort |
| Space | O(N) — for merged intervals and results |

---

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm

### Backend

```bash
cd backend
npm install
node index.js
```

Server starts at `http://localhost:3000`.

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend starts at `http://localhost:5173` (default Vite port).

Open the frontend URL in your browser and start adding meetings.

---

## API Reference

### `POST /api/schedule`

**Request Body:**

```json
{
  "meetings": [
    { "title": "Standup", "start": "09:00", "end": "09:30" },
    { "title": "Design Review", "start": "09:15", "end": "10:00" },
    { "title": "Sprint Planning", "start": "14:00", "end": "15:00" }
  ],
  "duration": 30
}
```

**Response:**

```json
{
  "conflicts": [
    "Conflict between \"Standup\" and \"Design Review\""
  ],
  "suggestions": [
    "10:00 - 14:00",
    "15:00 - 17:00"
  ]
}
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `meetings` | Array | Required | Array of meeting objects with `title`, `start`, `end` |
| `duration` | Number | 30 | Minimum free slot duration in minutes |

---

## Screenshots

*Run the application locally and add meetings to see the conflict detection and free slot suggestions in action.*

---

## Real-World Relevance

This project implements the same scheduling logic used in:

- **Google Calendar / Outlook** — Conflict warnings and "Find a time" suggestions.
- **Booking platforms (Airbnb, Hotels)** — Preventing double-booking of properties and rooms.
- **Hospital appointment systems** — Ensuring doctors are not scheduled for overlapping consultations.
- **University exam scheduling** — Guaranteeing no student has two exams at the same time.
- **Operating system schedulers** — Managing CPU time slices across competing processes.

---

## Future Improvements

- **Multiple room support** — Extend to the Meeting Rooms II problem using a min-heap to track room availability.
- **Database integration** — Persist meetings in PostgreSQL or MongoDB for cross-session state.
- **Timezone handling** — Store times in UTC and convert to local timezone on the client.
- **Recurring meetings** — Expand repeating events into individual intervals before running the merge.
- **Authentication** — Add user accounts for personalized scheduling.

