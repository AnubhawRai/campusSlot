// ponytail: group by room, then run the same merge-intervals per room.
const ROOMS = ['Room 1', 'Room 2', 'Room 3', 'Room 4', 'Room 5'];

const timeToMins = t => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const minsToTime = m => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;

const WORK_START = 9 * 60;
const WORK_END = 17 * 60;

const analyzeRoom = (meetings, durationMins) => {
    if (!meetings || meetings.length === 0) {
        return { conflicts: [], suggestions: [`${minsToTime(WORK_START)} - ${minsToTime(WORK_END)}`] };
    }

    const intervals = meetings.map(m => ({
        ...m,
        startMins: timeToMins(m.start),
        endMins: timeToMins(m.end)
    })).sort((a, b) => a.startMins - b.startMins);

    const merged = [];
    const conflicts = [];
    let current = intervals[0];

    for (let i = 1; i < intervals.length; i++) {
        const next = intervals[i];
        if (current.endMins > next.startMins) {
            conflicts.push(`"${current.title}" and "${next.title}" overlap (${current.start}-${current.end} vs ${next.start}-${next.end})`);
            current = {
                ...current,
                startMins: Math.min(current.startMins, next.startMins),
                endMins: Math.max(current.endMins, next.endMins)
            };
        } else {
            merged.push(current);
            current = next;
        }
    }
    merged.push(current);

    const suggestions = [];
    let prevEnd = WORK_START;
    for (const m of merged) {
        if (m.startMins - prevEnd >= durationMins) {
            suggestions.push(`${minsToTime(prevEnd)} - ${minsToTime(m.startMins)}`);
        }
        prevEnd = Math.max(prevEnd, m.endMins);
    }
    if (WORK_END - prevEnd >= durationMins) {
        suggestions.push(`${minsToTime(prevEnd)} - ${minsToTime(WORK_END)}`);
    }

    return { conflicts, suggestions, meetingCount: meetings.length };
};

const detectConflictsAndSuggest = (meetings, meetingDurationMins = 30) => {
    // group meetings by room
    const byRoom = {};
    ROOMS.forEach(r => { byRoom[r] = []; });
    for (const m of meetings) {
        const room = m.room || 'Room 1';
        if (!byRoom[room]) byRoom[room] = [];
        byRoom[room].push(m);
    }

    const results = {};
    let totalConflicts = 0;
    let totalMeetings = meetings.length;

    for (const room of ROOMS) {
        const analysis = analyzeRoom(byRoom[room], meetingDurationMins);
        results[room] = analysis;
        totalConflicts += analysis.conflicts.length;
    }

    return { rooms: results, totalMeetings, totalConflicts, availableRooms: ROOMS };
};

module.exports = { detectConflictsAndSuggest, ROOMS };
