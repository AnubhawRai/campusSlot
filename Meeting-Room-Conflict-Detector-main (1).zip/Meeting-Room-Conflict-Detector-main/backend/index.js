const express = require('express');
const cors = require('cors');
const { detectConflictsAndSuggest, ROOMS } = require('./scheduler');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/rooms', (_req, res) => res.json({ rooms: ROOMS }));

app.post('/api/schedule', (req, res) => {
    const { meetings, duration } = req.body;
    res.json(detectConflictsAndSuggest(meetings, duration || 30));
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Backend running on port ${port}`));
