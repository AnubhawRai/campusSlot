import { useState } from 'react'
import './index.css'

const ROOMS = ['Room 1', 'Room 2', 'Room 3', 'Room 4', 'Room 5']

function App() {
  const [meetings, setMeetings] = useState([])
  const [title, setTitle] = useState('')
  const [start, setStart] = useState('')
  const [end, setEnd] = useState('')
  const [room, setRoom] = useState('Room 1')
  const [result, setResult] = useState(null)

  const addMeeting = (e) => {
    e.preventDefault()
    if (!title || !start || !end) return
    setMeetings([...meetings, { title, start, end, room }])
    setTitle('')
    setStart('')
    setEnd('')
  }

  const removeMeeting = (idx) => {
    setMeetings(meetings.filter((_, i) => i !== idx))
    setResult(null)
  }

  const checkConflicts = async () => {
    try {
      const res = await fetch('http://localhost:3000/api/schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ meetings, duration: 30 })
      })
      setResult(await res.json())
    } catch (err) {
      console.error(err)
      alert('Failed to connect to backend')
    }
  }

  return (
    <div>
      <h1>Meeting Room Scheduler</h1>
      <p className="subtitle">5 rooms available — schedule meetings and check for conflicts</p>

      <div className="card">
        <form onSubmit={addMeeting}>
          <input type="text" placeholder="Meeting title" value={title} onChange={e => setTitle(e.target.value)} required />
          <select value={room} onChange={e => setRoom(e.target.value)}>
            {ROOMS.map(r => <option key={r} value={r}>{r}</option>)}
          </select>
          <input type="time" value={start} onChange={e => setStart(e.target.value)} required />
          <input type="time" value={end} onChange={e => setEnd(e.target.value)} required />
          <button type="submit">Add</button>
        </form>
      </div>

      {meetings.length > 0 && (
        <div className="card">
          <h3>Proposed Meetings ({meetings.length})</h3>
          <table>
            <thead>
              <tr><th>Title</th><th>Room</th><th>Time</th><th></th></tr>
            </thead>
            <tbody>
              {meetings.map((m, i) => (
                <tr key={i}>
                  <td>{m.title}</td>
                  <td>{m.room}</td>
                  <td>{m.start} – {m.end}</td>
                  <td><button className="btn-small" onClick={() => removeMeeting(i)}>✕</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <button onClick={checkConflicts}>Check Conflicts</button>
        </div>
      )}

      {result && (
        <div className="card">
          <h3>Analysis — {result.totalMeetings} meetings across 5 rooms</h3>

          {result.totalConflicts > 0 && (
            <div className="conflicts-block">
              <h4 className="error">Conflicts Detected</h4>
              {ROOMS.map(r => {
                const data = result.rooms[r]
                if (!data || data.conflicts.length === 0) return null
                return (
                  <div key={r} className="room-conflict">
                    <p className="error"><strong>{r}:</strong></p>
                    <ul>
                      {data.conflicts.map((c, i) => <li key={i} className="error">{c}</li>)}
                    </ul>
                  </div>
                )
              })}
            </div>
          )}

          {result.totalConflicts === 0 && <p className="success">No conflicts in any room.</p>}

          <h4>Free Slots Across All Rooms (30m+)</h4>
          {ROOMS.map(r => {
            const data = result.rooms[r]
            if (!data) return null
            return (
              <div key={r} className="room-section">
                <span className="room-label">{r}</span>
                {data.suggestions.length > 0 ? (
                  <ul className="suggestions">
                    {data.suggestions.map((s, i) => <li key={i}>{s}</li>)}
                  </ul>
                ) : (
                  <p className="muted">No free slots available</p>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default App
